# El ejercicio 3 y el 4 están hechos juntos

