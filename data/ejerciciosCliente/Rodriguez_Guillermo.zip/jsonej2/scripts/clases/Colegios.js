//**********************************CLASE COLEGIOS******************************* */
//Aqui meteremos el array con colegios
class Colegios {
    arrcolegios = [];

}